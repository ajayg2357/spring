package com.cg.empapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.empapp.bean.Employee;
import com.cg.empapp.dao.EmployeeDao;
@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDao employeeDao;
	@Override
	public List<Employee> getAllEmployees() {
		
		return employeeDao.findAll();
	}
	
	@Override
	public Employee getEmployeeById(int id) {
	
		return employeeDao.findById(id).get();
	}
	
	//update employee
	@Override
	public void updateEmployee(Employee emp) {
		
		employeeDao.save(emp);
	}
	
	//add employee
	@Override
	public void addEmployee(Employee emp) {
		
		employeeDao.save(emp);
	}
	//delete
	@Override
	public void deleteEmployee(int id) {
		
		employeeDao.deleteById(id);
	}
	//by gender
	@Override
	public List<Employee> getEmployeeByGender(String gender) {
		
		return employeeDao.getEmployeeByGender(gender);
	}

}
